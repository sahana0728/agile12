#sample print python script
print("Welcome to sample python program from docker")
print("******************")
